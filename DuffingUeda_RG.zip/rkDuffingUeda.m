function x=rkDuffingUeda(x0,u,h,t)
% function x=rkDuffingUeda(x0,u,h,t)
% 
% implements numerical integration using 4th-order Runge Kuta 
% x0 state vector before call the function (initial conditions)
% u forcing function which is kept constant throughout the integration interval, h
% h integration interval
% t time instant just before calling the function 
% the vector field is in dvDuffingUeda.m

% LAA 17/12/21

% 1a chamada
xd=dvDuffingUeda(x0,u,t);
savex0=x0;
phi=xd;
x0=savex0+0.5*h*xd;

% 2a chamada
xd=dvDuffingUeda(x0,u,t+0.5*h);
phi=phi+2*xd;
x0=savex0+0.5*h*xd;

% 3a chamada
xd=dvDuffingUeda(x0,u,t+0.5*h);
phi=phi+2*xd;
x0=savex0+h*xd;

% 4a chamada
xd=dvDuffingUeda(x0,u,t+h);
x=savex0+(phi+xd)*h/6;

