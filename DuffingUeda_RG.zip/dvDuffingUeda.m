function xdot=dvDuffingUeda(x,u,t)
%
% function dvDuffingUeda(x,u) 
% implements the equations for the Duffing-Ueda oscillator
% x state vector
% u forcing function
% xd time derivative of x (vector field at x) 
% x(1)=x
% x(2)=y
% x(3)=z

% LAA 17/12/21

% the parameter value used
K = evalin('base', 'K');

xd(1)=x(2);
xd(2)=-K*x(2)-x(1)^3+u;
xdot=xd';