% Produces a Poincare section of the Duffing-Ueda oscillator using 
% rkDuffingUeda.m and dvDuffingUeda.m

% LAA 17/12/21

clear
close all

% parameter value to be used in dvDuffingUeda.m
K = 0.1;

% initial and final times
t0 = 0;
tf = 5000;

% integration time (step) and time vector. Notice that the
% integration time must be a multiple of pi in order to 
% guarantee periodicity for sinusoidal inputs
h = pi/600;
t = t0:h:tf;

% random initial conditions
x0=randn(2,1)*0.1;

% initialization
x = zeros(2,length(t));
x(:,1) = x0;

% input
A = 11;
w = 1;
u = A*cos(w*t);

for k=2:length(t)
    x(:,k)=rkDuffingUeda(x(:,k-1),u(k),h,t(k));
end

% the period of the input is 2pi/w = 2pi
% the number of integration steps in that period is 2pi/h = 1200
% so sampling at each 1200 integration intervals correspond to
% stroboscopic sampling (in this case coincides with a Poincare 
% in the S x R^2 space).

% differential embedding
figure(1)
set(gca,'FontSize',18);
plot(x(1,10000:1200:end),x(2,10000:1200:end),'k.');
xlabel('x')
ylabel('dot{x}')

% delay embedding
figure(2)
set(gca,'FontSize',18);
plot(x(1,10000:1200:end),x(2,10000-40:1200:end-40),'k.');
xlabel('x(k)')
ylabel('x(k-40)')


% using this script it is simple to produce a bifurcation diagram
% for the Duffing-Ueda oscillator. All that needs to be done is
% to run this script for varying values of a bifurcation parameter
% e.g. 4.5 < A < 12 and plot the value of x(1) or x(2) *on the 
% Poincare section* as a function of A. This will take quite some
% computation time if the increments of A are small.


