% Simulates the Duffing-Ueda oscillator using rkDuffingUeda.m and dvDuffingUeda.m

% LAA 17/12/21

clear
close all

% parameter value to be used in dvDuffingUeda.m
K = 0.1;

% initial and final times
t0 = 0;
tf = 75;

% integration time (step) and time vector. Notice that the
% integration time must be a multiple of pi in order to 
% guarantee periodicity for sinusoidal inputs
h = pi/600;
t = t0:h:tf;

% random initial conditions
x0=randn(2,1)*0.1;

% initialization
x = zeros(2,length(t));
x(:,1) = x0;

% input
A = 11;
w = 1;
u = A*cos(w*t);

for k=2:length(t)
    x(:,k)=rkDuffingUeda(x(:,k-1),u(k),h,t(k));
end


figure(1)
set(gca,'FontSize',18);
plot(x(1,2000:10:14000),x(2,2000:10:14000),'k');
xlabel('x')
ylabel('dot{x}')




