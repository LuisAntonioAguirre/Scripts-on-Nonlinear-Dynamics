% Implements Pyragas' 1992 delayed feedback control for Rossler system

% Luis A Aguirre 6/6/16
% http://www.researcherid.com/rid/A-2737-2008

clear; close all


%%  Simulates the autonomous Rossler system 

% initial time
t0=0;

% final time
tf=400;

% integration interval
h=0.01;

% time vector
t=t0:h:tf;

% initial conditions (close to the central fixed point)
x0=[0.1;0.1;0.1];
x=zeros(length(x0),length(t));
x(:,1)=x0;

% no control (for now)
f=zeros(1,length(t));

% here is the control-free simulation
for k=2:10000
    x(:,k)=rkRossler(x(:,k-1),f(k),h,t(k));
end

% here the delay used in the feedback is varied over a range of values.
% The actual delay is tau*h
tau=400:10:2000; % faster
% tau=400:2000; % 10x slower, but with more detail

for j=1:length(tau)
    % displays tau to inform how far in the simulation you are
    disp(tau(j))
    
% Pyragas' control turned on
for k2=k+1:length(t)
    % delayed y variable minus the y value of the previous integration step
    D(k2)=x(2,k2-tau(j))-x(2,k2-1);
    
    % proportional control action with control gain 0.2 (this can be
    % changed manually)
    f(k2)=D(k2)*0.2; % see Eq. (5) in Pyragas' paper
    
    % simulate one step of Rossler with the computed control action
    x(:,k2)=rkRossler(x(:,k2-1),f(k2),h,t(k2));
end

% mean square difference (this is plotted in Figure 7a of Pyragas' paper
D2m(j)=mean(D(k+1+10000:length(t)).^2);
end



% this will produce a figure quite close to Figure 7a in Pyragas's paper
figure(1)
plot(tau*h,log10(D2m),'.')
