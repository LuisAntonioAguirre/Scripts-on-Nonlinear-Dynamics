% Implements Pyragas' 1992 external force control for Rossler's system.
% Here the external force is a UPO loaded from a data file (I provide 3
% different UPOs)

% Luis A Aguirre 6/6/16
% http://www.researcherid.com/rid/A-2737-2008

clear; close all

% load period-4 UPO 200
load 200.dat;
x200=X200(:,1);
y200=X200(:,2);
z200=X200(:,3);
figure(1)
plot3(x200,y200,z200);


% load period-5 UPO 100
load 100.dat;
x100=X100(:,1);
y100=X100(:,2);
z100=X100(:,3);
figure(2)
plot3(x100,y100,z100);


% load period-4 UPO 20100
load 20100.dat;
x20100=X20100(:,1);
y20100=X20100(:,2);
z20100=X20100(:,3);
figure(3)
plot3(x20100,y20100,z20100);


%% Pyragas' method with reference signal
% "external force control" Fig. 1a (Pyragas, 1992).
% Following Pyragas I will couple using the y variabe

close all

% initial time
t0=0;

% final time
tf=400;

% integration interval
h=0.01;

% time vector
t=t0:h:tf;

% controller gain
K=0.4;

% here you can choose one of the UPOs. I choose the period-5 one, and since
% conpling will be through the y variable, only this variable is needed.
OT=y100;

% length of the reference UPO
LOT=length(OT);

% circular indices (this is hard to follow... just accept it)
ic=[];
for i=1:ceil(length(t)/LOT)
  ic=[ic 1:LOT];
end

% initial conditions
x=zeros(3,length(t));
x(:,1)=[x200(1);y200(1);z200(1)];
x(:,1)=[0.1,0.1,0.1];
F=zeros(length(t),1);
ux=0;

for k=2:length(t)
    F(k-1)=K*(OT(ic(k))-x(2,k-1));
    x(:,k)=rkRossler_w(x(:,k-1),ux,F(k-1),h,t(k));
    
    % the following function is slightly more compact, but it is the same
    %[x(:,k),F(k)]=RwPcontrol(K,OT(ic(k)),u,x(:,k-1),h,t(k));
end

% transients included
figure(4)
plot3(x(1,:),x(2,:),x(3,:),x200,y200,z200,'r');

figure(5)
subplot(211)
set(gca,'FontSize',18)
plot(1:length(t),x(2,:),10*LOT:11*LOT-1,OT,'r');
axis([1 length(t) -20 13])
ylabel('y(t)');
title('UPO shown in red')
subplot(212)
set(gca,'FontSize',18)
plot(1:length(t),F);
axis([1 length(t) -4 4])
xlabel('k')
ylabel('Control action F(t)');



