function x=rkRossler(x0,u,h,t)
% function x=rk(x0,u,h,t)
% 
% implements 4th-order Runge Kutta numerical integration algorithm 
% x0 is the state vector (before calling the integration function - it is the initial condition of the current step)
% u is the control input, considered constant throughout the integration step h 
% h integration step (constant)
% t is the time instant just before calling the integration function 
% the vector field in in dvRossler.m

% Luis A Aguirre 3/6/16
% http://www.researcherid.com/rid/A-2737-2008

% 1st call
xd=dvRossler(x0,u,t);
savex0=x0;
phi=xd;
x0=savex0+0.5*h*xd;

% 2nd call
xd=dvRossler(x0,u,t+0.5*h);
phi=phi+2*xd;
x0=savex0+0.5*h*xd;

% 3rd call
xd=dvRossler(x0,u,t+0.5*h);
phi=phi+2*xd;
x0=savex0+h*xd;

% 4th call
xd=dvRossler(x0,u,t+h);
x=savex0+(phi+xd)*h/6;
