function xdot=dvRossler_w(x,ux,uy,t)
%
% function xd=dvRossler_w(x,u) 
% implements Rossler's system with explicit indication of main (average) frequency
% w frequency
% x state vector
% ux control input in 1st equation
% uy control input in 2nd equation
% xd time derivative of x (vector field at x)

% Luis A Aguirre 6/6/16
% http://www.researcherid.com/rid/A-2737-2008

a=0.28; b=0.1; c=8.5; w=1.0;

% Differential equations
xd(1)=-w*x(2)-x(3)+ux;
xd(2)=w*x(1)+a*x(2)+uy;
xd(3)=b+x(3)*(x(1)-c);

xdot=xd';