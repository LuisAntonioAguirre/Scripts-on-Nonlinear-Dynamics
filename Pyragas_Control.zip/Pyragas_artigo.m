% Procura reproduzir os resultados do metodo de Pyragas para o sistema de
% Rossler

% LAA 6/6/16

clear; close all


%%  Simula o sistema livre com contrle de Pyragas
close all
t0=0;
tf=400;
%a=0.2; b=0.2; c=5.7; % espiral
% intervalo de integracao
h=0.01;
t=t0:h:tf;

% condicoes iniciais
x0=[0.1;0.1;0.1];
x=zeros(length(x0),length(t));
x(:,1)=x0;
f=zeros(1,length(t));

% primeiro laco for eh para gerar dados historicos
for k=2:10000
    % simula o sistema livre
    x(:,k)=rkRossler(x(:,k-1),f(k),h,t(k));
end


tau=600:610;
for j=1:length(tau)
disp(tau(j))
    
% liga a acao de controle de Pyragas
for k2=k+1:length(t)
    D(k2)=x(2,k2-tau(j))-x(2,k2-1);
    f(k2)=D(k2)*0.4;
    x(:,k2)=rkRossler(x(:,k2-1),f(k2),h,t(k2));
end
D2m(j)=mean(D(k+1+10000:length(t)).^2);
%    figure(j)
%    plot(x(1,10000:end),x(2,10000:end));
end
% 
%figure(2)
%plot3(x(1,:),x(2,:),x(3,:));

plot(tau*h,D2m,'.')
