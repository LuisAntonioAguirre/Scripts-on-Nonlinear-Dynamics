function [x,F]=RwPcontrol(K,yi,u,x0,h,tk);
%
% function [x,F]=RwPcontrol(K,yi,x0,h,tk)
% Rossler with Pyraga's control
% x is a 3D state space vector of Rossler's variables 
% x0 is as x, but one integration interval (h) before
% K is the control gain used in Pyragas' control
% u is a user-defined control action. If only Pyragas' control is desired
% then u=0.
% yi is the external signal added to the second equation of Rossler
% tk is the current time. The output x corresponds to time tk+h
% F is the control action used at time tk, to produce x.

% Luis A Aguirre 11/7/16
% http://www.researcherid.com/rid/A-2737-2008


% Pyragas' control action
F=K*(yi-x0(2));
% User's control action is u will be applied to 1st equation
% calls integration routine
x=rkRossler_w(x0,u,F,h,tk);
