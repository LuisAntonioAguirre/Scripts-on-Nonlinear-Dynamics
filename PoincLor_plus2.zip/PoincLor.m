% Poincare Section for Lorenz system
% Luis Aguirre 19/10/17

clear
close all

% time definitions
t0=0;
tf=400;
h=0.001;
t=t0:h:tf;

% if parameters should be changed, remember to change also in rkLorenz.m
sigma=10; b=8/3; r=28;
e=randn(3,1)*0.1;
    
% Poincare section
% x at fixed point and dot(x)>0, this will be tested later
xp=sqrt(b*(r-1));

% initial conditions
x0=[e(1); e(2); e(3)];

% initialization
x=[x0 zeros(length(x0),length(t)-1)];
% no inputs (no external force)
u=zeros(length(t),1);



% initial time do avoid transients
ti=(tf/2)/h;


% initialiation of vector with indices of values at Poincare section
kp=zeros(1000,1);
i=1;
for k=2:length(t)
    % simulates the system
    x(:,k)=rkLorenz(x(:,k-1),u(k),h,t(k));  
    
    % The Poincare section will be defined as dot{z}=0 and ddot{z}<0
    % we compute these values
    xdot=-sigma*(x(1,k)-x(2,k));
    ydot=r*x(1,k)-x(2,k)-x(1,k)*x(3,k);
    zdot(k)=x(1,k)*x(2,k)-b*x(3,k);
    zddot(k)=xdot*x(2,k)+x(1,k)*ydot-b*zdot(k);
end




k=ti;
i=1;
while k<length(t)
    if abs(zdot(k))<26-0.01/h % if dot{z} is "close" to zero 
        if zddot(k)<0 % and if ddot(z)<0
            kp(i)=k;
            i=i+1;
            k=k+10*0.01/h; % a trick to avoid picking consecutive points
        end
    end  
k=k+1;
end



X=x(:,ti:length(t));

figure(1)
set(gca,'FontSize',18)
plot3(X(1,:),X(2,:),X(3,:),'k');
xlabel('x')
ylabel('y')
zlabel('z')
hold on
plot3(x(1,kp(2:i-1)),x(2,kp(2:i-1)),x(3,kp(2:i-1)),'ro');
hold off
grid

xpo=x(1,kp(2:i-1));
figure(2)
set(gca,'FontSize',18)
plot(abs(xpo(1:end-1)),abs(xpo(2:end)),'k.',[10 18],[10 18],'k-')
xlabel('|x_n|') 
ylabel('|x_{n+1}|') 


%%

% approximate "interpolation" (suggested only for "large" values of h; e.g. h=0.01)

% we fit a line on the |x|-|y| plane
p=polyfit(abs(x(1,kp(2:i-1))), abs(x(2,kp(2:i-1))),1);
% this turns out to be two lines if we consider negative values of x and y
ylinep=polyval(p,9:17); % positive values
ylinem=polyval([p(1) -p(2)],-17:-9); % negative values
% plot(x(1,kp(2:i-1)), x(2,kp(2:i-1)),'.',9:17,ylinep,'r',-17:-9,ylinem,'r')
% we therefore assume that approximately these lines relate x and y
% we will assume further that the z component found will not change
% finally, the other constraint we have (this one is exact) is that zdot=0
% this guives rise to the equation: p(1)x^2+p(2)x-b*z=0 (the sign of p(2) 
% must be changed for negative values of x and y. The roots of such 
% equation are potential values for the x component on the Poincare
% section. The corresponding y component is obtained from the line:
% y=p(2)+p(1)x, and the z component is not changed.

for k=2:i-1
    zpo(k)=x(3,kp(k));
    if x(1,kp(k))>0
        raizes=roots([p(1) p(2) -b*zpo(k)]);
        % clearly only the second (smallest) root is a possible solution
        xpo(k)=min(raizes);
        ypo(k)=p(2)+p(1)*xpo(k);
    else
        raizes=roots([p(1) -p(2) -b*zpo(k)]);
        % clearly only the second (largest) root is a possible solution
        xpo(k)=max(raizes);
        ypo(k)=-p(2)+p(1)*xpo(k);
    end
end



% Poincare section
figure(3)
set(gca,'FontSize',18)
plot(ypo(2:i-1),zpo(2:i-1),'k.')
xlabel('y_n') 
ylabel('z_n') 



% first-return map
figure(4)
set(gca,'FontSize',18)
plot(abs(xpo(2:i-2)),abs(xpo(3:i-1)),'k.')
xlabel('|x_n|') 
ylabel('|x_{n+1}|') 




