function x=rkLorenz(x0,u,h,t)
% function x=rk(x0,u,h,t)
% 
% implements 4th-order Runge Kuta algorithm for numerical integration
% x0 state vector (before calling the function... it is the initial condition for that step)
% u (if any), is the input vector considered constant duiring the integration interval, h
% h integration interval
% t time just before calling the integration function (rk<name>)
% The vector field should be in function dv<name>

% LAA 19/10/17

% 1st calling
xd=dvLorenz(x0,u,t);
savex0=x0;
phi=xd;
x0=savex0+0.5*h*xd;

% 2nd calling
xd=dvLorenz(x0,u,t+0.5*h);
phi=phi+2*xd;
x0=savex0+0.5*h*xd;

% 3rd calling
xd=dvLorenz(x0,u,t+0.5*h);
phi=phi+2*xd;
x0=savex0+h*xd;

% 4th calling
xd=dvLorenz(x0,u,t+h);
x=savex0+(phi+xd)*h/6;
