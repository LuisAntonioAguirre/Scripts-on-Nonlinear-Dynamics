function xdot=dvLorenz(x,u,t)
%
% function dvLorenz(x,u) 
% implements equations for Lorenz system
% x state vector
% u input (whenever used)
% xd time derivative of x (vector field at x)
% x(1)=x
% x(2)=y
% x(3)=z

% LAA 19/10/17


sigma=10;
r=28; 
b=8/3;


xd(1)=-sigma*(x(1)-x(2));
xd(2)=r*x(1)-x(2)-x(1)*x(3);
xd(3)=x(1)*x(2)-b*x(3);
xdot=xd';