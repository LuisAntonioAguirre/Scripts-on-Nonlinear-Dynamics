function x = cerecurr_y(signal1,signal2,epsilon)
%This program produces a joint recurrence plot of the, possibly multivariate,
%data sets. That means, for each point in the data set it looks for all 
%points, such that the distance between these two points is smaller 
%than a given size in a given embedding space. Whenever this happens for
%both signals, then there is a joint recurrence. Adapted from 

%Author: Hui Yang
%Affiliation: 
       %%The Pennsylvania State University
       %310 Leohard Building, University Park, PA
       %Email: yanghui@gmail.com

%input:
%signal1 and signal 2: input time series of two systems of same length  
%epsilon: threshold for deciding the recurrences

%output:
%x - Matrix containing the indices of joint recurrences.



% If you find this demo useful, please cite the following paper:
% [1]	H. Yang, �Multiscale Recurrence Quantification Analysis of Spatial Vectorcardiogram (VCG) 
% Signals,� IEEE Transactions on Biomedical Engineering, Vol. 58, No. 2, p339-347, 2011
% DOI: 10.1109/TBME.2010.2063704
% [2]	Y. Chen and H. Yang, "Multiscale recurrence analysis of long-term nonlinear and 
% nonstationary time series," Chaos, Solitons and Fractals, Vol. 45, No. 7, p978-987, 2012 
% DOI: 10.1016/j.chaos.2012.03.013

len = length(signal1);
N = len;
Y = signal1;
X = signal2;
x = [];

%h = waitbar(0,'Please wait...');
for i=1:N
    %waitbar(i/N);
    x0=i;
    for j=i:N
        y0=j;
        % Calculate the euclidean distance
        distance1 = norm(Y(i,:)-Y(j,:));
        if distance1 <=epsilon % this is a recurrence for Y
          distance2 = norm(X(i,:)-X(j,:));
          if distance2 <=epsilon % this is a recurrence for X
            % Store the indices for the joint recurrence
            x = [x;i j;j i]; 
          end
        end
    end
end
%close(h);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if nargout == 0
    figure('Position',[100 100 550 400]);
    plot(x(:,1),x(:,2),'k.',x(:,2),x(:,1),'k.','MarkerSize',2);
    axis([0 N 0 N])
    axis('square')
    xlabel('Índice','FontSize',16);
    ylabel('Índice','FontSize',16);
    %title('Recurrence Plot','FontSize',16);
    get(gcf,'CurrentAxes');
    set(gca,'LineWidth',1,'FontSize',16);
    %grid on;
end



