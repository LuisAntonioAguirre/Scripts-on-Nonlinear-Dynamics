% Simulates a coupled pair of Rossler systems
% and computes the Joint Recurrence Plot

% LAA 25/1/21

clear; close all

%% 
% Simulates the coupled Rossler system

t0=0; % initial time
tf=200; % final time
% integration interval
h=0.05;
t=t0:h:tf; % time vector



% initial conditions
x0=[0.1;0.1;0.1;0.05;0.05;0.05];

% initialization
x=[x0 zeros(length(x0),length(t)-1)];
% frequency vector. If the values are equal, then there is no mismatch
w=[0.98 1];
% coupling strength
mu=0.3;


for k=2:length(t)
    x(:,k)=rkRossCoupled(x(:,k-1),w,mu,h,t(k));
end

figure(1)
plot3(x(1,1000:end),x(2,1000:end),x(3,1000:end));
set(gca,'FontSize',18)
xlabel('x1')
ylabel('y1')
zlabel('z1')

figure(2)
plot3(x(4,1000:end),x(5,1000:end),x(6,1000:end));
set(gca,'FontSize',18)
xlabel('x2')
ylabel('y2')
zlabel('z2')

figure(3)
subplot(311)
plot(x(1,1000:end)-x(4,1000:end),'k');
axis([0 length(x(1,1000:end)) -20 20])
ylabel('x_1-x_2');
subplot(312)
plot(x(2,1000:end)-x(5,1000:end),'k');
axis([0 length(x(1,1000:end)) -20 20])
ylabel('y_1-y_2');
subplot(313)
plot(x(3,1000:end)-x(6,1000:end),'k');
axis([0 length(x(1,1000:end)) -40 40])
ylabel('z_1-z_2');

%% Let us compute the RPs

% Let us choose the time delay using mutual information
mutual(x(1,1000:end),16,50);
delay=30;

%%
% Let us choose the dimension using the false nearest neighbors algorithm
Z=false_nearest(x(1,1000:end),1,5,delay);
false = Z(:,1:2);
%plot(false(:,1),false(:,2),'o-','MarkerSize',4.5);
plot(false(:,1),false(:,2),'o-');
%title('False nearest neighbor test','FontSize',10,'FontWeight','bold');
xlabel('dimension');
ylabel('FNN');

dim=3;

%%
% reconstruct the embedding space from a time series
y1 = phasespace(x(1,1000:end),dim,delay);
y2 = phasespace(x(4,1000:end),dim,delay);

% original state space (using all state variables)
% y1=x(1:3,1000:end)';
plot3(y1(:,1),y1(:,2),y1(:,3),'-','LineWidth',1);
xlabel('x(t)','FontSize',10,'FontWeight','bold');
ylabel('x(t+\tau)','FontSize',10,'FontWeight','bold');
zlabel('x(t+2\tau)','FontSize',10,'FontWeight','bold');
view(0,40);



% RP for the first oscillator
recurdata1 = cerecurr_y(y1);
tdrecurr_y(recurdata1,1);
% JRP is a subset of the former
jcerecurr_y(y1,y2,1);

%=========================================================
function xdot=dvRossCoupled(x,w,mu,t)
%
% function xdot=dvRossCoupled(x,ux,uy,t)
% implements the a pair of coupled Rossler systems using the first variable
% x state vector (six states, the first three are from one oscillator)
% w is the frequency 2D vector (values around 1). First value for the first
% oscillator.
% mu is the coupling strength
% xd time derivative of x (vector field at x)

% The Rossler system with explicit frequency parameter 
% used in order to facilitate parameter mismatch

% LAA 25/1/21

a=0.15; %0.398
b=0.2; % 2
c=10; % 4

% first oscillator
xd(1)=-w(1)*x(2)-x(3);
xd(2)=w(1)*x(1)+a*x(2)+mu*(x(5)-x(2));
xd(3)=b+x(3)*(x(1)-c);

% second oscillator
xd(4)=-w(2)*x(5)-x(6);
xd(5)=w(2)*x(4)+a*x(5)+mu*(x(2)-x(5));
xd(6)=b+x(6)*(x(4)-c);

xdot=xd';

% end dvRossCoupled
end


%=========================================================
function x=rkRossCoupled(x0,w,mu,h,t)
% function x=rkRossCoupled(x0,w,mu,h,t)
% 
% This function implements a numerical integration algorithm known as 4th-order Runge-Kutta  
% x0 is the state vector BEFORE calling the function (i.e. the initial condition at each integration step) 
% w is the frequency 2D vector (values around 1). First value for the first
% oscillator.
% mu is the coupling strength
% h integration interval.
% t the time BEFORE calling the function.
% The vector field (the equations) are in function dvRossCoupled

% LAA 25/1/21

% 1st evaluation
xd=dvRossCoupled(x0,w,mu,t);
savex0=x0;
phi=xd;
x0=savex0+0.5*h*xd;

% 2nd evaluation
xd=dvRossCoupled(x0,w,mu,t+0.5*h);
phi=phi+2*xd;
x0=savex0+0.5*h*xd;

% 3rd evaluation
xd=dvRossCoupled(x0,w,mu,t+0.5*h);
phi=phi+2*xd;
x0=savex0+h*xd;

% 4th evaluation
xd=dvRossCoupled(x0,w,mu,t+h);
x=savex0+(phi+xd)*h/6;

% end rkRossCoupled
end
