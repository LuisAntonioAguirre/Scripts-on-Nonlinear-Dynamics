function xdot=dvLorenz(x,u,t)
%
% function dvLorenz(x,u) 
% implements the equations for the Lorenz system
% x state vector
% u not used (the autonomous case is simulated)
% xd time derivative of x (vector field at x) 
% x(1)=x
% x(2)=y
% x(3)=z

% LAA 18/10/18


sigma=10;
r=28; 
b=8/3;

xd(1)=sigma*(x(2)-x(1));
xd(2)=r*x(1)-x(2)-x(1)*x(3);
xd(3)=-b*x(3)+x(1)*x(2);
xdot=xd';