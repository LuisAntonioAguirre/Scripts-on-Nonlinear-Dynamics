% Simulates Lorenz system using rkLorenz.m and dvLorenz.m
% from two close sets of initial conditions to illustrate the
% extreme sensitivity to initial conditions, which is a signature of
% chaotic systems

% LAA 18/10/18

clear
close all

% initial and final times
t0=0;
tf=15;

% integration time (step) and time vector
h=0.001;
t=t0:h:tf;

% two sets of close initial conditions
x0=[-10;   -10;   20];
x=[x0 zeros(length(x0),length(t)-1)];
y0=[-10.01;   -10.01;   20.01];
y=[y0 zeros(length(x0),length(t)-1)];
u=zeros(1,length(t));

for k=2:length(t)
    x(:,k)=rkLorenz(x(:,k-1),u(k),h,t(k));
    y(:,k)=rkLorenz(y(:,k-1),u(k),h,t(k));
end
X=x';
[linha,coluna]=size(X);


figure(1)
set(gca,'FontSize',18);
plot(t,x(1,:),'k',t,y(1,:),'k--');
xlabel('t')
ylabel('x')
%axis([-150 900 1 49])


% print -dpng /home/luis/Dropbox/Latex/book3/figures/lorenzSI.png

