%=======================================================
function xdot=dvRossler(x,u,t)
%
% function xd=dvRossler(x,u,t) 
% implements the vector field for Rossler's system
% x state vector
% u control input. Here it is placed in the second equation. This can be
% changed manually
% t is the time instant just before calling the integration function
% xd time derivative of x (vector field at x)

% Luis A Aguirre 3/6/16
% http://www.researcherid.com/rid/A-2737-2008


%a=0.398; b=2; c=4; %standard
% a=0.2; b=0.2; c=5.7; %Pyragas paper

a = evalin('base', 'a');
b = evalin('base', 'b');
c = evalin('base', 'c');

% Differential equations
xd(1)=-x(2)-x(3);
xd(2)=x(1)+a*x(2)+u;
xd(3)=b+x(3)*(x(1)-c);

xdot=xd';
