% Symbolic sequenced and entropy calculation for Rossler system on
% the spiral regime, that is, when only two symbols are needed.
% This Script uses code from PoincRoss.m

% Luis Aguirre 11/01/22

clear
close all

%%

% time definitions
t0 = 0; 
tf = 3000;
h = 0.01;
t = t0:h:tf;

% parameters 
a = 0.398; b = 2; c = 4; % standard spiral
% a = 0.388; % more simple chaos than standard spiral
% a=0.42; % more complicated/develped chaos than standard spiral 
    
% Poincare section
% x at fixed point and dot(x)>0, this will be tested later
xp = (c-sqrt(c^2-4*a*b))/2;

% initial conditions
x0 = randn(3,1)*0.1;

% initialization
x = [x0 zeros(length(x0),length(t)-1)];
% no inputs (no external force)
u = zeros(length(t),1);


% initial time index do avoid transients
ti = (tf/2)/h;

 
% initialiation of vector with indices of values at Poincare section
kp = zeros(1000,1);
i = 1;
for k = 2:length(t)
    % simulates the system
    x(:,k) = rkRossler(x(:,k-1),u(k),h,t(k));       
end

k = ti;
i = 1;

while k<length(t)
    if x(1,k) > xp % if x passed fixed point coordinate 
        if -x(2,k)-x(3,k) > 0 % and if dot(x)>0
            kp(i) = k; % kp accumulates the indices of points close to the Poincare section
            i = i+1;
            k = k+500;
        end
    end  
    k = k+1;
end


%%

% interpolation on any coordinate and even on time is achieved by
% using propotions (rule of three). Remember that the coordinate on the
% x axis is given by the Poincare section, therefore xp is known.

for j=2:i-1
    % inclination of interpolation line in x-y plane
    alphay=(x(2,kp(j))-x(2,kp(j)-1))/(x(1,kp(j))-x(1,kp(j)-1));
    % intercept of interpolation line in x-y plane
    betay=(x(2,kp(j)-1)*x(1,kp(j))-x(2,kp(j))*x(1,kp(j)-1))/(x(1,kp(j))-x(1,kp(j)-1));
    % line
    ypo(j)=betay+alphay*xp;
    
    % inclination of interpolation line in z-y plane
    alphaz=(x(3,kp(j))-x(3,kp(j)-1))/(x(2,kp(j))-x(2,kp(j)-1));
    % intercept of interpolation line in z-y plane
    betaz=(x(3,kp(j)-1)*x(2,kp(j))-x(3,kp(j))*x(2,kp(j)-1))/(x(2,kp(j))-x(2,kp(j)-1));
    % line
    zpo(j)=betaz+alphaz*ypo(j);
    
    % time interpolation
    tp(j)=((x(2,kp(j)-1)-ypo(j))*t(kp(j))+(ypo(j)-x(2,kp(j)))*t(kp(j)-1))/(x(2,kp(j)-1)-x(2,kp(j)));
end


%%




% first-return map
figure(1)
plot(-ypo(2:i-2),-ypo(3:i-1),'k.',[0 8],[0 8],'k-')
set(gca,'FontSize',18)
xlabel('-y_n') 
ylabel('-y_{n+1}') 

% finding the maximum
maximo = -max(-ypo(3:end)); 
% finding the correspondig x-value
ind = find(ypo(3:end) == maximo);
% citical value
cv = ypo(ind+1); 

symbols = zeros(length(tp),1);
% whenever -y_n > -cv symbol is 1
ind_1 = find(-ypo > -cv+0.001) ;
symbols(ind_1) = 1;

% symbol 0 cycles

figure(2)
plot3([-6 6],[-6 3],[0 6],'w.')
xlabel('x');
ylabel('y');
zlabel('z');
set(gca,'FontSize',18)
hold on
axis([-6 6 -6 3 0 7])
grid
 
% for the sake simplicity, we plot the cycle starting from the Poincare
% section with a fixed duration (600 steps = 6s). For this attractor this
% is almost the time required to return to the Poincare section

for j = 2:length(tp)-1
    % find time index: first element in tind
    tind = find(t > tp(j));
    % plot corresponding cycle
    if symbols(j) == 0 % if symbol 0 plot black
        plot3(x(1,tind(1):tind(1)+600),x(2,tind(1):tind(1)+600),x(3,tind(1):tind(1)+600),'k-');
    else % if symbol 1 plot red
        plot3(x(1,tind(1):tind(1)+600),x(2,tind(1):tind(1)+600),x(3,tind(1):tind(1)+600),'r:');
    end
end
hold off


%%

% word size q
q = 4;
% number or words
Nw = floor(length(tp)/q);
words = zeros(Nw,q+1);

for j = 1:Nw
    words(j,1:q) = symbols((j-1)*q+1:j*q)';
    aux = 0;
    for jj = q:-1:1
        aux = aux + words(j,jj)*2^(q-jj);
    end
    words(j,q+1) = aux;
end

% For each row of matrix words, the first q columns form a binary word and
% the last colum is the corresponding decimal number

% approximate probability of words. We discard the first word which is
% usually problematic because of border effects
p = hist(words(2:end,q+1),0:2^q)/(Nw-1);

% entropy
En = 0;
for j = 1:length(p)
    if p(j) > 0
        En = En -p(j)*log2(p(j));
    end
end

    
%%
% histogram of words
hist(words(2:end,q+1),0:2^q)