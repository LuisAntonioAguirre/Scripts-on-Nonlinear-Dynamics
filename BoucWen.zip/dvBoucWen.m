function xdot=dvBoucWen(x,u,t)
%
% function dvBoucWenm(x,u) 
% implements the equations for the Buc-Wen model for hysteresis
% x is the state (usually called h)
% u is the derivative (velocity) of the input
% xd time derivative of x (vector field at x) 
% x(1)=h

% LAA 25/12/18

% constant parameters
A=0.7091;
beta=2.0476; 
gamma=0.1949;

xdot=A*u-beta*abs(u)*x(1)-gamma*u*abs(x(1));