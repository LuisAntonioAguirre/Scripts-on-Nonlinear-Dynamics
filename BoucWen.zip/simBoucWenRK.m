% Simulates the Bouc-Wen system using rkBoucWen.m and dvBoucWen.m
% the rate-independent character of the Bouc-Wen model for hysteresis is
% displayed

% LAA 25/12/18

clear
close all

% initial and final times
t0=0;
tf=15;

% integration time (step) and time vector
h=0.001;
t=t0:h:tf;

% initial condition
x0=0;
x10=[x0 zeros(length(x0),length(t)-1)];
x2=x10;

% periodic inputs to produce loop
w=10;
U10=sin(w*t);
w=2;
U2=sin(w*t);


% the derivative is needed for the simulation
w=10;
u10=w*cos(w*t);
w=2;
u2=w*cos(w*t);

% plot the 10 rad/s case
figure(1)
set(gca,'FontSize',18);
plot(t,U10,t,u10)
xlabel('time')
ylabel('input and time derivative at 10 rad/s')
axis([0 15 -10.5 10.5])

    
% Notice that the input parameer u(k) of the function rkBoucWen corresponds
% to the input derivative.

for k=2:length(t)
    % simulate both cases
    x10(:,k)=rkBoucWen(x10(:,k-1),u10(k),h,t(k));
    x2(:,k)=rkBoucWen(x2(:,k-1),u2(k),h,t(k));
end


% time signals
figure(2)
set(gca,'FontSize',18);
plot(t(10000:end),x10(1,10000:end),'k',t(10000:end),x2(1,10000:end),'b');
xlabel('t')
ylabel('outputs')
axis([t(10000) t(end) -0.4 0.4])

% hysteresis loops. Notice that both loops are very close. This is because
% the Bouc-Wen model is rate-independent
figure(3)
set(gca,'FontSize',18);
plot(U10(10000:end),x10(10000:end),'k:',U2(10000:end),x2(10000:end),'b-.')
xlabel('inputs')
ylabel('outputs')
%axis([-1.2 1.2 -0.4 0.4])


