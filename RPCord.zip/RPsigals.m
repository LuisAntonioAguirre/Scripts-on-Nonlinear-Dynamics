% Recurrence plot (RP) for periodic and random signals

% LAA 1/12/20

clear; close all

%% 
% Produces sinusoid

t0=0; % initial time
tf=50; % final time
% time interval
h=0.05;
t=t0:h:tf; % time vector

% periodic signal
T=5;
w=2*pi/T;
x=sin(w*t);

% random signa (coment next line for periodic signal)
x=rand(1000,1);

% Let us choose the time delay using mutual information
% mutual(x);
% for the sine
% delay=14;
% dim=2;

% for random
delay=1;
dim=3;

% reconstruct the embedding space from a time series
y = phasespace(x,dim,delay);

recurdata = cerecurr_y(y);
tdrecurr_y(recurdata,0.1);
