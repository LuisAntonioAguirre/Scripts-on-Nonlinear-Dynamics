% Simulates a network of Kuramoto oscillators using rkKuramoto.m and dvKuramoto.m

% LAA 8/1/19

clear
close all

% initial and final times
t0=0;
tf=200;

% integration time (step) and time vector
h=0.1;
t=t0:h:tf;

% Graph of the network
n = 10;                                              % number of nodes
Adj = diag(ones(n-1,1),-1) + diag(ones(n-1,1),+1);  % adjacency matrix
rho = 0.15;                                          % coupling strength

% initial condition
x0=randn(n,1);
% the state history will go here
x=[x0 zeros(n,length(t)-1)];

% natural frequencies of the oscillators taken randomly around 1 rad/s
w=randn(n,1)*0.01+ones(n,1);

% simulate
for k=2:length(t)
    x(:,k)=rkKuramoto(x(:,k-1),n,w,rho,Adj,h,t(k));
end

% vector of absolute phase differences between oscillators o1 and o2
o1=1;
o2=n;
errp=abs(x(o1,:)-x(o2,:));


% time signals
figure(1)
subplot(211)
set(gca,'FontSize',18);
plot(t,x);
xlabel('t')
ylabel('oscillator phases, x_i')
subplot(212)
set(gca,'FontSize',18);
plot(t,errp);
xlabel('t')
ylabel('|x_i - x_j|')

