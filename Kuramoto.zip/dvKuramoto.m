function xd=dvKuramoto(x,n,w,rho,Adj,t)
%
% function dvKuramoto(x,n,w,rho,Adj,t)
% implements the equations for a network of Kuramoto oscillators
% x is the state of the full network of size n
% w is the (column) vector of parameters (natural frequency of each oscillator)
% the number of nodes in the network is length(w)=length(x)=n
% rho is the coupling strength which is the same for every existing
% coupling
% Adj is the adjacency matrix. It indicates the connections among the
% oscillators. Adj(i,j)=1 indicates that there is a directed link from node
% j to node i. This is a square matrix of dimension length(x)=n.
% t is the time vector
% xd is the time derivative of x (vector field at x) 

% LAA 8/1/19


xd=w + rho*sum(sin(ones(n,1)*x' -x*ones(1,n)).*Adj, 2);
