function x=rkKuramoto(x0,n,w,rho,Adj,h,t)
% function x=rkKuramoto(x0,n,w,rho,Adj,h,t)
% 
% implements numerical integration using 4th-order Runge Kuta 
% x0 state vector before call the function (initial conditions)
% w is the (column) vector of parameters (natural frequency of each oscillator)
% the number of nodes in the network is length(w)=length(x)=n
% rho is the coupling strength which is the same for every existing
% coupling
% Adj is the adjacency matrix. It indicates the connections among the
% oscillators. Adj(i,j)=1 indicates that there is a directed link from node
% j to node i. This is a square matrix of dimension length(x)=n.
% h integration interval
% t time instant just before calling the function 
% the vector field is in dvKuramoto.m

% LAA 8/1/19

% 1a chamada
xd=dvKuramoto(x0,n,w,rho,Adj,t);
savex0=x0;
phi=xd;
x0=savex0+0.5*h*xd;

% 2a chamada
xd=dvKuramoto(x0,n,w,rho,Adj,t+0.5*h);
phi=phi+2*xd;
x0=savex0+0.5*h*xd;

% 3a chamada
xd=dvKuramoto(x0,n,w,rho,Adj,t+0.5*h);
phi=phi+2*xd;
x0=savex0+h*xd;

% 4a chamada
xd=dvKuramoto(x0,n,w,rho,Adj,t+h);
x=savex0+(phi+xd)*h/6;
