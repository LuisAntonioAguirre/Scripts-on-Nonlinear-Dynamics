% Simulates the Li system in dvLi.m by performing numerical integration
% using the algorithm implemented in rkLi.m 

% LAA 15/8/18

clear; close all


t0=0; % initial time
tf=50; % final time
% integration interval
h=0.001;
t=t0:h:tf; % time vector


% initial conditions
x0=[0.1;0.1;0.1];

% initialization
x=[x0 zeros(length(x0),length(t)-1)];
% no inputs (no external force)
u=zeros(length(t),1);


for k=2:length(t)
    x(:,k)=rkLi(x(:,k-1),u(k),u(k),h,t(k));
end

figure(1)
plot(t,x(1,:));
set(gca,'FontSize',18)
xlabel('time')
ylabel('x')
figure(2)
plot(t,x(2,:));
set(gca,'FontSize',18)
xlabel('time')
ylabel('y')
figure(3)
plot3(x(1,5000:end),x(2,5000:end),x(3,5000:end));
set(gca,'FontSize',18)
xlabel('x')
ylabel('y')
zlabel('z')


