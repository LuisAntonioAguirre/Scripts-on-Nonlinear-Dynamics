function xdot=dvLi(x,ux,uy,t)
%
% function xdot=dvLi(x,ux,uy,t)
% implements the Li system
% x state vector
% the system has no inputs so ux=uy=0
% xd time derivative of x (vector field at x)

% The Li system

%
% First published in
%
% Li, D., A three-scroll chaotic attractor, Physics Letters A, 372(4):387-393,
% 2008.

a=42;
c=11/6;
d=0.16;
e=0.65;
k=55;
F=20;


xd(1)=a*(x(2)-x(1))+d*x(1)*x(3);
xd(2)=k*x(1)+F*x(2)-x(1)*x(3);
xd(3)=c*x(3)+x(1)*x(2)-e*x(1)^2;

xdot=xd';